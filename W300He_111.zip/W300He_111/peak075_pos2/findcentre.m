function find_centre = findcentre(input_matrix)

I_sum = 0;
X_sum = 0;
Y_sum=0;
Z_sum =0;

for i=1:size(input_matrix,1)
    I_sum = I_sum + input_matrix(i,4);
    X_sum = X_sum + input_matrix(i,1)*input_matrix(i,4);
    Y_sum = Y_sum + input_matrix(i,2)*input_matrix(i,4);
    Z_sum = Z_sum + input_matrix(i,3)*input_matrix(i,4);
end

find_centre(1,1) = X_sum/I_sum;
find_centre(1,2) = Y_sum/I_sum;
find_centre(1,3) = Z_sum/I_sum;

end