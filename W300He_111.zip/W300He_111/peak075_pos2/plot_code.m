
q3d_data = Q3D(2:end,2:end);

%find qx
qx_start=Q3D(2,1);
for i=3:size(Q3D,1);
    if Q3D(i,1) <= qx_start
        break;
    end
end
qx = Q3D(2:(i-1),1);

%find qy

%find qz
count=0;
for i=3:size(Q3D,1)
    if Q3D(i,1) == Q3D(2,1)
        count = count+1;
    end
end

stepsize = (QZ_coord(3,4) - QZ_coord(2,4))/(count-1);
qz_grid = meshgrid(QZ_coord(2,4):stepsize:QZ_coord(3,4));
qz = transpose(qz_grid(1,:));

%constructing matrix with qx in coulm 1, qy in col2, qz in col 3 and
%intensity in col 4
q3d_data(q3d_data==0) = NaN;
q3d_data(isnan(q3d_data)) = -5;

row=1;
q_matrix_row=1;
for i=1:size(qz,1)
    for j=1:size(qx,1)
        for k=1:size(qy,1)
            q_matrix(q_matrix_row,1) = qx(j,1); %storing x component
            q_matrix(q_matrix_row,2) = qy(k,1); %storing y component 
            q_matrix(q_matrix_row,3) = qz(i,1); %storing z component
            q_matrix(q_matrix_row,4) = q3d_data(row,k); %storing q_data component
            q_matrix_row = q_matrix_row +1;  
        end
        row=row+1;
    end
end

%removing all NaN or zero data from intensity
j=1;
for i=1:size(q_matrix,1)
    if q_matrix(i,4) ~= -5
        q_matrix_new(j,1) = q_matrix(i,1);
        q_matrix_new(j,2) = q_matrix(i,2);
        q_matrix_new(j,3) = q_matrix(i,3);
        q_matrix_new(j,4) = q_matrix(i,4);
        j=j+1;
    end
end

figure
scatter3(q_matrix_new(:,1),q_matrix_new(:,2),q_matrix_new(:,3),1,q_matrix_new(:,4));
colorbar;

q_matrix_centre = findcentre(q_matrix_new);
hold on;
scatter3(q_matrix_centre(1,1),q_matrix_centre(1,2), q_matrix_centre(1,3),20,'red');




